
   var mapURLs = {"3f0e9738-d0fa-ac06-055b-b99b31e95dbf":"/d2l/le/content/6928/viewContent/6479/view","72e0a098-b5c7-fb1f-b61e-04bc40ac6053":"/d2l/le/content/6928/viewContent/6480/view","9465d11b-3644-a4a9-f015-a48c37070909":"/d2l/le/content/6928/viewContent/6481/view","abd6d25c-0a89-e546-1542-e3da8194e890":"/d2l/le/content/6928/viewContent/6482/view","d19a6fda-b6bc-c95f-530c-6625dae633ac":"/d2l/le/content/6928/viewContent/6483/view","d1dc3d47-829f-c502-ef44-1d192b127b74":"/d2l/le/content/6928/viewContent/6484/view"}
   var mapPath = "/d2l/le/content/6928/viewContent/6485/view";
   
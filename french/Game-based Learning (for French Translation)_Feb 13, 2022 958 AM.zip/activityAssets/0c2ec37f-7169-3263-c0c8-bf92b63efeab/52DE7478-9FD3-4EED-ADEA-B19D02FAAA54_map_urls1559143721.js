
   var mapURLs = {"3f0e9738-d0fa-ac06-055b-b99b31e95dbf":"/d2l/le/content/6928/viewContent/6847/view","72e0a098-b5c7-fb1f-b61e-04bc40ac6053":"/d2l/le/content/6928/viewContent/6848/view","9465d11b-3644-a4a9-f015-a48c37070909":"/d2l/le/content/6928/viewContent/6849/view","abd6d25c-0a89-e546-1542-e3da8194e890":"/d2l/le/content/6928/viewContent/6850/view","d19a6fda-b6bc-c95f-530c-6625dae633ac":"/d2l/le/content/6928/viewContent/6851/view","d1dc3d47-829f-c502-ef44-1d192b127b74":"/d2l/le/content/6928/viewContent/6852/view"}
   var mapPath = "/d2l/le/content/6928/viewContent/6853/view";
   
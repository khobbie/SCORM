
   var mapURLs = {"0742b33e-f910-ab2c-c827-a544689c847a":"/d2l/le/content/6928/viewContent/6472/view","0c8abfb9-1939-b489-e632-156785e43c61":"/d2l/le/content/6928/viewContent/6473/view","1d51a1cd-b30c-dcb3-77ae-bcc9e26938b5":"/d2l/le/content/6928/viewContent/6474/view","277b0f97-7744-b020-926c-06a2a7a618f1":"/d2l/le/content/6928/viewContent/6475/view","8d05d16e-a96b-6464-b537-bb2c2a912939":"/d2l/le/content/6928/viewContent/6476/view"}
   var mapPath = "/d2l/le/content/6928/viewContent/6477/view";
   